/*
 * ============================================================================
 *  jsonrpc_schema.c  —  JSON-RPC Schema v1: 7 method groups + async events
 * ============================================================================
 *
 *  T2T Step 3.2 — Research & Brainstorming
 *
 *  Branch A — Single flat dispatch table in jsonrpc.c
 *    Decision: REJECTED. Unmaintainable as method count grows; violates
 *    single-responsibility; mixes schema docs with transport logic.
 *
 *  Branch B — Grouped schema file + separate method table
 *    Decision: ACCEPTED. Clean separation; each group is documented and
 *    versioned; companion app can query schema for UI generation.
 *
 *  Branch C — Dynamic runtime method registration via linked list
 *    Decision: REJECTED. Overhead and fragmentation; static table is
 *    sufficient and safer for embedded.
 * ============================================================================
 */

#include <string.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "esp_log.h"
#include "cJSON.h"

#include "jsonrpc.h"
#include "jsonrpc_schema.h"
#include "usb_cdc.h"
#include "health_telemetry.h"
#include "watchdog.h"
#include "structured_log.h"
#include "storage_spiffs.h"
#include "nvs_persist.h"
#include "wifi_sniffer.h"
#include "cli_transport.h"
#include "gps.h"
#include "coex.h"
#include "ai_model.h"
#include "ai_classifier.h"
#include "ai_anomaly.h"
#include "ai_fingerprint.h"
#include "ai_channel_predictor.h"
#include "ai_handshake_quality.h"
#include "ai_rogue_detector.h"
#include "ai_deauth_predictor.h"
#include "ai_ble_profiler.h"
#include "ai_training.h"
#include "wardrive.h"
#include "attack_planner.h"
#include "stealth.h"
#include "scheduler.h"
#include "reaction_rules.h"
#include "export.h"
#include "export.h"
#include "pcap_ring.h"
#include "offensive.h"
#include "cli_flipper.h"
#include "pmkid.h"
#include "sae_sidechannel.h"
#include "dragonfly_sim.h"
#include "ft_roam.h"
#include "neighbor_report.h"
#include "btm.h"
#include "wps_pixiedust.h"
#include "eap_capture.h"
#include "ble_mitm.h"
#include "ble_gatt_enumerator.h"
#include "ble_rpa_bypass.h"
#include "ble_findmy.h"
#include "ble_smarttag.h"
#include "thread_border_router.h"
#include "matter_commissioner.h"
#include "zigbee_sniffer.h"
#include "platform_secure_boot.h"
#include "platform_antitamper.h"
#include "platform_factory_test.h"
#include "platform_config.h"
#include "platform_plugins.h"
#include "platform_fleet.h"
#include "health_ai_monitor.h"
#include "wordlist_manager.h"

static const char *TAG = "jsonrpc_schema";

#define SCHEMA_VERSION "v1.0.0"

/*============================================================================*/
static esp_err_t rpc_gps_set_fix(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    gps_fix_t fix;
    memset(&fix, 0, sizeof(fix));

    cJSON *lat = cJSON_GetObjectItem(root, "lat");
    cJSON *lon = cJSON_GetObjectItem(root, "lon");
    cJSON *alt = cJSON_GetObjectItem(root, "alt");
    cJSON *sats = cJSON_GetObjectItem(root, "sats");
    cJSON *fix_q = cJSON_GetObjectItem(root, "fix");
    cJSON *ts = cJSON_GetObjectItem(root, "timestamp");

    if (cJSON_IsNumber(lat)) fix.latitude = cJSON_GetNumberValue(lat);
    if (cJSON_IsNumber(lon)) fix.longitude = cJSON_GetNumberValue(lon);
    if (cJSON_IsNumber(alt)) fix.altitude = cJSON_GetNumberValue(alt);
    if (cJSON_IsNumber(sats)) fix.sat_count = (uint8_t)cJSON_GetNumberValue(sats);
    if (cJSON_IsNumber(fix_q)) fix.fix_quality = (uint8_t)cJSON_GetNumberValue(fix_q);
    if (cJSON_IsNumber(ts)) fix.timestamp = (uint32_t)cJSON_GetNumberValue(ts);

    fix.valid = (fix.latitude != 0.0 || fix.longitude != 0.0) &&
                fix.fix_quality >= 1 && fix.sat_count >= 3;

    esp_err_t rc = gps_set_fix(&fix);
    cJSON_Delete(root);

    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "gps_set_fix failed", out, out_sz);
    }

    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

static esp_err_t rpc_gps_get_fix(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    gps_fix_t fix;
    bool valid = gps_get_fix(&fix);

    cJSON *root = cJSON_CreateObject();
    cJSON_AddBoolToObject(root, "valid", valid);
    cJSON_AddNumberToObject(root, "lat", fix.latitude);
    cJSON_AddNumberToObject(root, "lon", fix.longitude);
    cJSON_AddNumberToObject(root, "alt", fix.altitude);
    cJSON_AddNumberToObject(root, "sats", fix.sat_count);
    cJSON_AddNumberToObject(root, "fix", fix.fix_quality);
    cJSON_AddNumberToObject(root, "timestamp", fix.timestamp);

    const char *json = cJSON_PrintUnformatted(root);
    esp_err_t rc = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(root);
    return rc;
}

static esp_err_t rpc_gps_status(const char *method, const char *params_json,
                                char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    cJSON *root = cJSON_CreateObject();

    bool valid = gps_is_valid();
    cJSON_AddBoolToObject(root, "valid", valid);
    cJSON_AddStringToObject(root, "source", valid ? "phone" : "none");
    cJSON_AddNumberToObject(root, "timestamp", gps_get_timestamp_us() / 1000000ULL);

    gps_fix_t fix;
    if (gps_get_fix(&fix)) {
        cJSON_AddNumberToObject(root, "lat", fix.latitude);
        cJSON_AddNumberToObject(root, "lon", fix.longitude);
    }

    const char *json = cJSON_PrintUnformatted(root);
    esp_err_t rc = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(root);
    return rc;
}

/*============================================================================*/
static esp_err_t rpc_coex_set_pref(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *pref = cJSON_GetObjectItem(root, "pref");
    if (pref == NULL) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing pref", out, out_sz);
    }

    const char *pref_str = cJSON_GetStringValue(pref);
    coex_pref_t p = COEX_PREF_BALANCE;
    if (pref_str && strcmp(pref_str, "wifi") == 0) p = COEX_PREF_WIFI;
    else if (pref_str && strcmp(pref_str, "ble") == 0) p = COEX_PREF_BLE;
    else if (pref_str && strcmp(pref_str, "balance") == 0) p = COEX_PREF_BALANCE;
    else {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "pref must be wifi|ble|balance", out, out_sz);
    }

    esp_err_t rc = coex_set_preference(p);
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "coex_set_preference failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

static esp_err_t rpc_coex_get_status(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = coex_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "coex status failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_coex_json(const char *method, const char *params_json,
                               char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = coex_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "coex json failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ai_load(const char *method, const char *params_json,
                             char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_model_zoo_load(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "ai_model_zoo_load failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"loaded\"", out, out_sz);
}

static esp_err_t rpc_ai_unload(const char *method, const char *params_json,
                               char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_model_zoo_unload(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK && rc != ESP_ERR_NOT_FOUND) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "ai_model_zoo_unload failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"unloaded\"", out, out_sz);
}

static esp_err_t rpc_ai_infer(const char *method, const char *params_json,
                              char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    cJSON *input = cJSON_GetObjectItem(root, "input");
    if (name == NULL || !cJSON_IsString(name) ||
        input == NULL || !cJSON_IsString(input)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name or input", out, out_sz);
    }

    const char *input_str = cJSON_GetStringValue(input);
    size_t input_len = strlen(input_str);
    uint8_t output[256];
    size_t out_len = 0;

    esp_err_t rc = ai_model_zoo_infer(cJSON_GetStringValue(name),
                                      input_str, input_len,
                                      output, sizeof(output), &out_len);
    cJSON_Delete(root);
    if (rc == ESP_ERR_NOT_SUPPORTED) {
        cJSON *r = cJSON_CreateObject();
        cJSON_AddStringToObject(r, "status", "stub");
        cJSON_AddStringToObject(r, "note", "link ESP-DL to enable inference");
        const char *json = cJSON_PrintUnformatted(r);
        esp_err_t r2 = jsonrpc_send_result(-1, json, out, out_sz);
        cJSON_free((void *)json);
        cJSON_Delete(r);
        return r2;
    }
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "inference failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

static esp_err_t rpc_ai_list(const char *method, const char *params_json,
                             char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[512];
    esp_err_t rc = ai_model_zoo_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "ai list failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ai_classify_test(const char *method, const char *params_json,
                                      char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *frame_hex = cJSON_GetObjectItem(root, "frame");
    if (frame_hex == NULL || !cJSON_IsString(frame_hex)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing frame hex", out, out_sz);
    }

    const char *hex = cJSON_GetStringValue(frame_hex);
    size_t hex_len = strlen(hex);
    uint8_t frame[AI_CLASSIFIER_INPUT_MAX];
    size_t frame_len = 0;
    for (size_t i = 0; i < hex_len && frame_len < sizeof(frame); i += 2) {
        unsigned int byte = 0;
        if (sscanf(hex + i, "%02x", &byte) == 1) {
            frame[frame_len++] = (uint8_t)byte;
        }
    }

    ai_classify_result_t res;
    esp_err_t rc = ai_classifier_predict(frame, frame_len, &res);
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "classify failed", out, out_sz);
    }

    cJSON *r = cJSON_CreateObject();
    cJSON_AddStringToObject(r, "class", ai_classifier_class_name(res.cls));
    cJSON_AddNumberToObject(r, "confidence", res.confidence);
    cJSON_AddNumberToObject(r, "inference_us", res.inference_us);
    cJSON_AddBoolToObject(r, "model_loaded", res.model_loaded);

    const char *json = cJSON_PrintUnformatted(r);
    esp_err_t r2 = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(r);
    return r2;
}

static esp_err_t rpc_ai_classify_stats(const char *method, const char *params_json,
                                       char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = ai_classifier_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "classify stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_classify_set_model(const char *method, const char *params_json,
                                           char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_classifier_set_model(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "set_model failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ai_anomaly_set_model(const char *method, const char *params_json,
                                           char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_anomaly_set_model(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "set_model failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

static esp_err_t rpc_ai_anomaly_set_threshold(const char *method, const char *params_json,
                                              char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *th = cJSON_GetObjectItem(root, "threshold");
    if (th == NULL || !cJSON_IsNumber(th)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing threshold", out, out_sz);
    }

    esp_err_t rc = ai_anomaly_set_threshold((float)cJSON_GetNumberValue(th));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "set_threshold failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

static esp_err_t rpc_ai_anomaly_stats(const char *method, const char *params_json,
                                      char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = ai_anomaly_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "anomaly stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ai_fp_set_model(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_fingerprint_set_model(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "set_model failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

static esp_err_t rpc_ai_fp_stats(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = ai_fingerprint_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "fp stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_fp_test(const char *method, const char *params_json,
                                char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *ie_hex = cJSON_GetObjectItem(root, "ie");
    cJSON *subtype_item = cJSON_GetObjectItem(root, "subtype");
    cJSON *oui_item = cJSON_GetObjectItem(root, "oui");
    if (ie_hex == NULL || !cJSON_IsString(ie_hex) ||
        subtype_item == NULL || !cJSON_IsNumber(subtype_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing ie or subtype", out, out_sz);
    }

    const char *ie_str = cJSON_GetStringValue(ie_hex);
    size_t ie_hex_len = strlen(ie_str);
    uint8_t ie_buf[256];
    size_t ie_len = 0;
    for (size_t i = 0; i < ie_hex_len && ie_len < sizeof(ie_buf); i += 2) {
        unsigned int byte = 0;
        if (sscanf(ie_str + i, "%02x", &byte) == 1) {
            ie_buf[ie_len++] = (uint8_t)byte;
        }
    }

    uint8_t oui[3] = {0};
    if (oui_item && cJSON_IsArray(oui_item)) {
        int cnt = cJSON_GetArraySize(oui_item);
        for (int i = 0; i < 3 && i < cnt; i++) {
            cJSON *item = cJSON_GetArrayItem(oui_item, i);
            if (cJSON_IsNumber(item)) oui[i] = (uint8_t)cJSON_GetNumberValue(item);
        }
    }

    ai_fp_result_t res;
    esp_err_t rc = ai_fingerprint_classify(ie_buf, ie_len,
                                           (uint8_t)cJSON_GetNumberValue(subtype_item),
                                           oui, &res);
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "classify failed", out, out_sz);
    }

    cJSON *r = cJSON_CreateObject();
    cJSON_AddStringToObject(r, "class", ai_fingerprint_class_name(res.cls));
    cJSON_AddStringToObject(r, "label", res.label);
    cJSON_AddNumberToObject(r, "inference_us", res.inference_us);
    cJSON_AddBoolToObject(r, "model_loaded", res.model_loaded);

    const char *json = cJSON_PrintUnformatted(r);
    esp_err_t r2 = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(r);
    return r2;
}

/*============================================================================*/
static esp_err_t rpc_ai_channel_predict(const char *method, const char *params_json,
                                        char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    ai_channel_predict_t pred;
    esp_err_t rc = ai_channel_predictor_predict(&pred);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "predict failed", out, out_sz);
    }

    cJSON *r = cJSON_CreateObject();
    cJSON_AddNumberToObject(r, "channel", pred.best_channel);
    cJSON_AddNumberToObject(r, "confidence", pred.confidence);
    cJSON_AddNumberToObject(r, "history", pred.history_count);
    cJSON_AddBoolToObject(r, "model_loaded", pred.model_loaded);
    cJSON_AddNumberToObject(r, "inference_us", pred.inference_us);

    const char *json = cJSON_PrintUnformatted(r);
    esp_err_t r2 = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(r);
    return r2;
}

static esp_err_t rpc_ai_channel_stats(const char *method, const char *params_json,
                                      char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = ai_channel_predictor_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "channel stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_channel_record(const char *method, const char *params_json,
                                       char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = ai_channel_predictor_record();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "record failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"recorded\"", out, out_sz);
}

static esp_err_t rpc_ai_channel_set_model(const char *method, const char *params_json,
                                          char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_channel_predictor_set_model(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "set_model failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ai_hs_score(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    ai_hs_quality_t q;
    esp_err_t rc = ai_hs_quality_score(&q);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "score failed", out, out_sz);
    }

    cJSON *r = cJSON_CreateObject();
    cJSON_AddNumberToObject(r, "score", q.score);
    cJSON_AddNumberToObject(r, "factors", q.factors);
    cJSON_AddNumberToObject(r, "m1", q.m1_count);
    cJSON_AddNumberToObject(r, "m2", q.m2_count);
    cJSON_AddNumberToObject(r, "rssi", q.rssi);
    cJSON_AddBoolToObject(r, "complete", q.complete);
    cJSON_AddBoolToObject(r, "anonce", q.has_anonce);
    cJSON_AddBoolToObject(r, "snonce", q.has_snonce);
    cJSON_AddBoolToObject(r, "mic", q.has_mic);
    cJSON_AddBoolToObject(r, "pmkid", q.has_pmkid);

    const char *json = cJSON_PrintUnformatted(r);
    esp_err_t r2 = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(r);
    return r2;
}

static esp_err_t rpc_ai_hs_stats(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = ai_hs_quality_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "hs stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_hs_set_model(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_hs_quality_set_model(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "set_model failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

static esp_err_t rpc_ai_hs_test(const char *method, const char *params_json,
                                char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *score_val = cJSON_GetObjectItem(root, "score");
    if (score_val == NULL || !cJSON_IsNumber(score_val)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing score", out, out_sz);
    }

    ai_hs_quality_t q;
    memset(&q, 0, sizeof(q));
    q.score = (float)cJSON_GetNumberValue(score_val);
    if (q.score > 1.0f) q.score = 1.0f;
    if (q.score < 0.0f) q.score = 0.0f;

    cJSON *r = cJSON_CreateObject();
    cJSON_AddNumberToObject(r, "score", q.score);
    cJSON_AddStringToObject(r, "verdict",
        q.score > 0.7f ? "high" :
        q.score > 0.4f ? "medium" : "low");

    const char *json = cJSON_PrintUnformatted(r);
    esp_err_t r2 = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(r);
    cJSON_Delete(root);
    return r2;
}

/*============================================================================*/
static esp_err_t rpc_ai_rogue_scan(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = ai_rogue_detector_scan();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "rogue scan failed", out, out_sz);
    }
    char buf[512];
    rc = ai_rogue_detector_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "rogue json failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_rogue_alerts(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[512];
    esp_err_t rc = ai_rogue_detector_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "rogue alerts failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ai_deauth_predict(const char *method, const char *params_json,
                                       char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *idx_item = cJSON_GetObjectItem(root, "idx");
    if (idx_item == NULL || !cJSON_IsNumber(idx_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing idx", out, out_sz);
    }

    uint8_t idx = (uint8_t)cJSON_GetNumberValue(idx_item);
    ai_deauth_prediction_t pred;
    esp_err_t rc = ai_deauth_predictor_predict(idx, &pred);
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "predict failed", out, out_sz);
    }

    cJSON *r = cJSON_CreateObject();
    cJSON_AddNumberToObject(r, "idx", pred.target_index);
    cJSON_AddNumberToObject(r, "probability", pred.probability);
    cJSON_AddNumberToObject(r, "flags", pred.flags);
    cJSON_AddBoolToObject(r, "model_loaded", pred.model_loaded);
    cJSON_AddNumberToObject(r, "inference_us", pred.inference_us);

    const char *json = cJSON_PrintUnformatted(r);
    esp_err_t r2 = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(r);
    return r2;
}

static esp_err_t rpc_ai_deauth_predict_all(const char *method, const char *params_json,
                                           char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = ai_deauth_predictor_predict_all();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "predict_all failed", out, out_sz);
    }
    char buf[512];
    rc = ai_deauth_predictor_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "json failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_deauth_stats(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = ai_deauth_predictor_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "deauth stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_deauth_set_model(const char *method, const char *params_json,
                                         char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_deauth_predictor_set_model(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "set_model failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ai_ble_classify(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *mac_item = cJSON_GetObjectItem(root, "mac");
    cJSON *adv_item = cJSON_GetObjectItem(root, "adv");
    if (mac_item == NULL || !cJSON_IsString(mac_item) ||
        adv_item == NULL || !cJSON_IsString(adv_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing mac or adv", out, out_sz);
    }

    const char *mac_str = cJSON_GetStringValue(mac_item);
    const char *adv_str = cJSON_GetStringValue(adv_item);

    uint8_t mac[6] = {0};
    for (int i = 0; i < 6 && mac_str[i*2] && mac_str[i*2+1]; i++) {
        unsigned int byte = 0;
        sscanf(mac_str + i*2, "%02x", &byte);
        mac[i] = (uint8_t)byte;
    }

    size_t adv_hex_len = strlen(adv_str);
    uint8_t adv_buf[256];
    size_t adv_len = 0;
    for (size_t i = 0; i < adv_hex_len && adv_len < sizeof(adv_buf); i += 2) {
        unsigned int byte = 0;
        if (sscanf(adv_str + i, "%02x", &byte) == 1) {
            adv_buf[adv_len++] = (uint8_t)byte;
        }
    }

    ai_ble_profile_t profile;
    esp_err_t rc = ai_ble_profiler_classify(mac, adv_buf, adv_len, &profile);
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "classify failed", out, out_sz);
    }

    cJSON *r = cJSON_CreateObject();
    cJSON_AddStringToObject(r, "class", ai_ble_profiler_class_name(profile.cls));
    cJSON_AddStringToObject(r, "label", profile.label);
    cJSON_AddNumberToObject(r, "inference_us", profile.inference_us);
    cJSON_AddBoolToObject(r, "model_loaded", profile.model_loaded);

    const char *json = cJSON_PrintUnformatted(r);
    esp_err_t r2 = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(r);
    return r2;
}

static esp_err_t rpc_ai_ble_stats(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = ai_ble_profiler_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "ble stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_ble_set_model(const char *method, const char *params_json,
                                      char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *name = cJSON_GetObjectItem(root, "name");
    if (name == NULL || !cJSON_IsString(name)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing name", out, out_sz);
    }

    esp_err_t rc = ai_ble_profiler_set_model(cJSON_GetStringValue(name));
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "set_model failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ai_train_start(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }

    cJSON *mode_item = cJSON_GetObjectItem(root, "mode");
    if (mode_item == NULL || !cJSON_IsString(mode_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing mode", out, out_sz);
    }

    const char *mode_str = cJSON_GetStringValue(mode_item);
    ai_train_mode_t mode = AI_TRAIN_MODE_OFF;
    if (strcmp(mode_str, "wifi") == 0) mode = AI_TRAIN_MODE_WIFI;
    else if (strcmp(mode_str, "ble") == 0) mode = AI_TRAIN_MODE_BLE;
    else if (strcmp(mode_str, "both") == 0) mode = AI_TRAIN_MODE_BOTH;
    else {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "mode must be wifi|ble|both", out, out_sz);
    }

    esp_err_t rc = ai_train_start(mode);
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "train start failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"started\"", out, out_sz);
}

static esp_err_t rpc_ai_train_stop(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = ai_train_stop();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "train stop failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"stopped\"", out, out_sz);
}

static esp_err_t rpc_ai_train_stats(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = ai_train_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "train stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_ai_train_status(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[128];
    const char *mode_str = "off";
    switch (ai_train_get_mode()) {
        case AI_TRAIN_MODE_WIFI: mode_str = "wifi"; break;
        case AI_TRAIN_MODE_BLE: mode_str = "ble"; break;
        case AI_TRAIN_MODE_BOTH: mode_str = "both"; break;
        default: mode_str = "off"; break;
    }
    snprintf(buf, sizeof(buf), "\"%s\"", mode_str);
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_wardrive_start(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    cJSON *mode_item = cJSON_GetObjectItem(root, "mode");
    if (mode_item == NULL || !cJSON_IsString(mode_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing mode", out, out_sz);
    }
    const char *mode_str = cJSON_GetStringValue(mode_item);
    wardrive_mode_t mode = str_to_mode(mode_str);
    if (mode == WARDIRVE_MODE_OFF) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "mode must be wifi|ble|both", out, out_sz);
    }
    esp_err_t rc = wardrive_start(mode);
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "wardrive start failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"started\"", out, out_sz);
}

static esp_err_t rpc_wardrive_stop(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = wardrive_stop();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "wardrive stop failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"stopped\"", out, out_sz);
}

static esp_err_t rpc_wardrive_stats(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = wardrive_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "wardrive stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_wardrive_status(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    const char *s = "off";
    switch (wardrive_get_mode()) {
        case WARDIRVE_MODE_WIFI: s = "wifi"; break;
        case WARDIRVE_MODE_BLE: s = "ble"; break;
        case WARDIRVE_MODE_BOTH: s = "both"; break;
        default: s = "off"; break;
    }
    char buf[32];
    snprintf(buf, sizeof(buf), "\"%s\"", s);
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_attack_plan(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    cJSON *idx_item = cJSON_GetObjectItem(root, "idx");
    if (idx_item == NULL || !cJSON_IsNumber(idx_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing idx", out, out_sz);
    }
    int ap_index = cJSON_GetNumberValue(idx_item);
    cJSON_Delete(root);

    attack_plan_t plan;
    esp_err_t rc = attack_planner_build_plan((uint32_t)ap_index, &plan);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "plan failed", out, out_sz);
    }
    cJSON *res = cJSON_CreateObject();
    cJSON_AddStringToObject(res, "bssid", plan.bssid);
    cJSON_AddStringToObject(res, "ssid", plan.ssid);
    cJSON_AddNumberToObject(res, "channel", plan.channel);
    cJSON_AddNumberToObject(res, "security", plan.security);
    cJSON_AddBoolToObject(res, "pmf_required", plan.pmf_required);
    cJSON_AddNumberToObject(res, "score", plan.score);
    cJSON_AddStringToObject(res, "warning", plan.warning);
    cJSON *steps = cJSON_CreateArray();
    for (uint8_t i = 0; i < plan.step_count; i++) {
        cJSON_AddItemToArray(steps, cJSON_CreateString(attack_step_name(plan.steps[i])));
    }
    cJSON_AddItemToObject(res, "steps", steps);
    cJSON_AddStringToObject(res, "summary", plan.summary);
    char *printed = cJSON_PrintUnformatted(res);
    esp_err_t rc2 = jsonrpc_send_result(-1, printed, out, out_sz);
    cJSON_Delete(res);
    cJSON_free(printed);
    return rc2;
}

static esp_err_t rpc_attack_best(const char *method, const char *params_json,
                                char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    uint32_t best_idx = 0;
    esp_err_t rc = attack_planner_best_target(&best_idx);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "no target found", out, out_sz);
    }

    ap_info_t ap;
    rc = wifi_sniffer_get_ap(best_idx, &ap);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "ap fetch failed", out, out_sz);
    }

    char bssid[18];
    snprintf(bssid, sizeof(bssid), "%02X:%02X:%02X:%02X:%02X:%02X",
             ap.bssid[0], ap.bssid[1], ap.bssid[2],
             ap.bssid[3], ap.bssid[4], ap.bssid[5]);

    attack_plan_t plan;
    rc = attack_planner_build_plan(best_idx, &plan);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "plan failed", out, out_sz);
    }

    cJSON *res = cJSON_CreateObject();
    cJSON_AddStringToObject(res, "bssid", bssid);
    cJSON_AddStringToObject(res, "ssid", ap.ssid);
    cJSON_AddNumberToObject(res, "channel", ap.channel);
    cJSON_AddNumberToObject(res, "score", plan.score);
    cJSON_AddStringToObject(res, "summary", plan.summary);
    char *printed = cJSON_PrintUnformatted(res);
    esp_err_t rc2 = jsonrpc_send_result(-1, printed, out, out_sz);
    cJSON_Delete(res);
    cJSON_free(printed);
    return rc2;
}

static esp_err_t rpc_attack_stats(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = attack_planner_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_stealth_set_mode(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    cJSON *mode_item = cJSON_GetObjectItem(root, "mode");
    if (mode_item == NULL || !cJSON_IsString(mode_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing mode", out, out_sz);
    }
    const char *mode_str = cJSON_GetStringValue(mode_item);
    stealth_mode_t mode = STEALTH_MODE_OFF;
    if (strcmp(mode_str, "passive") == 0) mode = STEALTH_MODE_PASSIVE;
    else if (strcmp(mode_str, "active") == 0) mode = STEALTH_MODE_ACTIVE;
    else if (strcmp(mode_str, "off") == 0) mode = STEALTH_MODE_OFF;
    else {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "mode must be off|passive|active", out, out_sz);
    }
    esp_err_t rc = stealth_set_mode(mode);
    cJSON_Delete(root);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "stealth set_mode failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

static esp_err_t rpc_stealth_rotate(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = stealth_set_random_mac();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "rotate failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"rotated\"", out, out_sz);
}

static esp_err_t rpc_stealth_status(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[128];
    esp_err_t rc = stealth_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "stealth status failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_scheduler_add(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    sched_entry_t entry;
    memset(&entry, 0, sizeof(entry));
    entry.enabled = true;

    cJSON *min = cJSON_GetObjectItem(root, "minute");
    if (min != NULL && cJSON_IsNumber(min)) entry.minute = (uint8_t)cJSON_GetNumberValue(min);

    cJSON *hr = cJSON_GetObjectItem(root, "hour");
    if (hr != NULL && cJSON_IsNumber(hr)) entry.hour = (uint8_t)cJSON_GetNumberValue(hr);

    cJSON *dow = cJSON_GetObjectItem(root, "day_of_week");
    if (dow != NULL && cJSON_IsNumber(dow)) entry.day_of_week = (uint8_t)cJSON_GetNumberValue(dow);

    cJSON *act = cJSON_GetObjectItem(root, "action");
    if (act != NULL && cJSON_IsString(act)) {
        const char *as = cJSON_GetStringValue(act);
        if (strcmp(as, "wifi_start") == 0) entry.action = SCHED_ACTION_WIFI_START;
        else if (strcmp(as, "wifi_stop") == 0) entry.action = SCHED_ACTION_WIFI_STOP;
        else if (strcmp(as, "stealth") == 0) entry.action = SCHED_ACTION_STEALTH_SET_MODE;
        else if (strcmp(as, "wardrive_start") == 0) entry.action = SCHED_ACTION_WARDRIVE_START;
        else if (strcmp(as, "wardrive_stop") == 0) entry.action = SCHED_ACTION_WARDRIVE_STOP;
        else if (strcmp(as, "train_start") == 0) entry.action = SCHED_ACTION_AI_TRAIN_START;
        else if (strcmp(as, "train_stop") == 0) entry.action = SCHED_ACTION_AI_TRAIN_STOP;
        else if (strcmp(as, "jsonrpc") == 0) entry.action = SCHED_ACTION_CUSTOM_JSONRPC;
    }

    cJSON *params = cJSON_GetObjectItem(root, "params");
    if (params != NULL && cJSON_IsString(params)) {
        strncpy(entry.params, cJSON_GetStringValue(params), sizeof(entry.params) - 1);
        entry.params[sizeof(entry.params) - 1] = '\0';
    }

    int idx = scheduler_add(&entry);
    cJSON_Delete(root);
    if (idx < 0) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "scheduler add failed", out, out_sz);
    }
    cJSON *res = cJSON_CreateNumber((double)idx);
    char *printed = cJSON_PrintUnformatted(res);
    esp_err_t rc = jsonrpc_send_result(-1, printed, out, out_sz);
    cJSON_Delete(res);
    cJSON_free(printed);
    return rc;
}

static esp_err_t rpc_scheduler_remove(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    cJSON *idx_item = cJSON_GetObjectItem(root, "idx");
    if (idx_item == NULL || !cJSON_IsNumber(idx_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing idx", out, out_sz);
    }
    int idx = (int)cJSON_GetNumberValue(idx_item);
    cJSON_Delete(root);
    esp_err_t rc = scheduler_remove((uint8_t)idx);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "remove failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"removed\"", out, out_sz);
}

static esp_err_t rpc_scheduler_update(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    cJSON *idx_item = cJSON_GetObjectItem(root, "idx");
    if (idx_item == NULL || !cJSON_IsNumber(idx_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing idx", out, out_sz);
    }
    int idx = (int)cJSON_GetNumberValue(idx_item);

    sched_entry_t entry;
    memset(&entry, 0, sizeof(entry));
    entry.enabled = true;

    cJSON *min = cJSON_GetObjectItem(root, "minute");
    if (min != NULL && cJSON_IsNumber(min)) entry.minute = (uint8_t)cJSON_GetNumberValue(min);

    cJSON *hr = cJSON_GetObjectItem(root, "hour");
    if (hr != NULL && cJSON_IsNumber(hr)) entry.hour = (uint8_t)cJSON_GetNumberValue(hr);

    cJSON *dow = cJSON_GetObjectItem(root, "day_of_week");
    if (dow != NULL && cJSON_IsNumber(dow)) entry.day_of_week = (uint8_t)cJSON_GetNumberValue(dow);

    cJSON *act = cJSON_GetObjectItem(root, "action");
    if (act != NULL && cJSON_IsString(act)) {
        const char *as = cJSON_GetStringValue(act);
        if (strcmp(as, "wifi_start") == 0) entry.action = SCHED_ACTION_WIFI_START;
        else if (strcmp(as, "wifi_stop") == 0) entry.action = SCHED_ACTION_WIFI_STOP;
        else if (strcmp(as, "stealth") == 0) entry.action = SCHED_ACTION_STEALTH_SET_MODE;
        else if (strcmp(as, "wardrive_start") == 0) entry.action = SCHED_ACTION_WARDRIVE_START;
        else if (strcmp(as, "wardrive_stop") == 0) entry.action = SCHED_ACTION_WARDRIVE_STOP;
        else if (strcmp(as, "train_start") == 0) entry.action = SCHED_ACTION_AI_TRAIN_START;
        else if (strcmp(as, "train_stop") == 0) entry.action = SCHED_ACTION_AI_TRAIN_STOP;
        else if (strcmp(as, "jsonrpc") == 0) entry.action = SCHED_ACTION_CUSTOM_JSONRPC;
    }

    cJSON *params = cJSON_GetObjectItem(root, "params");
    if (params != NULL && cJSON_IsString(params)) {
        strncpy(entry.params, cJSON_GetStringValue(params), sizeof(entry.params) - 1);
        entry.params[sizeof(entry.params) - 1] = '\0';
    }

    cJSON_Delete(root);
    esp_err_t rc = scheduler_update((uint8_t)idx, &entry);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "update failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"updated\"", out, out_sz);
}

static esp_err_t rpc_scheduler_list(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[1024];
    esp_err_t rc = scheduler_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "list failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

static esp_err_t rpc_scheduler_save(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = scheduler_save();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "save failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"saved\"", out, out_sz);
}


/*============================================================================*/
static esp_err_t rpc_reaction_add(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    reaction_rule_t rule;
    memset(&rule, 0, sizeof(rule));
    rule.enabled = true;

    cJSON *trig = cJSON_GetObjectItem(root, "trigger");
    if (trig != NULL && cJSON_IsString(trig)) {
        const char *ts = cJSON_GetStringValue(trig);
        if (strcmp(ts, "ap_seen") == 0) rule.trigger = REACTION_TRIG_AP_SEEN;
        else if (strcmp(ts, "client_join") == 0) rule.trigger = REACTION_TRIG_CLIENT_JOIN;
        else if (strcmp(ts, "anomaly_high") == 0) rule.trigger = REACTION_TRIG_ANOMALY_HIGH;
        else if (strcmp(ts, "ble_seen") == 0) rule.trigger = REACTION_TRIG_BLE_SEEN;
        else if (strcmp(ts, "handshake") == 0) rule.trigger = REACTION_TRIG_HANDSHAKE;
        else if (strcmp(ts, "rogue_ap") == 0) rule.trigger = REACTION_TRIG_ROGUE_AP;
    }

    cJSON *act = cJSON_GetObjectItem(root, "action");
    if (act != NULL && cJSON_IsString(act)) {
        const char *as = cJSON_GetStringValue(act);
        if (strcmp(as, "deauth") == 0) rule.action = REACTION_ACT_DEAUTH;
        else if (strcmp(as, "wardrive") == 0) rule.action = REACTION_ACT_WARDRIVE_START;
        else if (strcmp(as, "stealth_passive") == 0) rule.action = REACTION_ACT_STEALTH_PASSIVE;
        else if (strcmp(as, "train_start") == 0) rule.action = REACTION_ACT_TRAIN_START;
        else if (strcmp(as, "train_stop") == 0) rule.action = REACTION_ACT_TRAIN_STOP;
        else if (strcmp(as, "alert") == 0) rule.action = REACTION_ACT_ALERT;
    }

    cJSON *param = cJSON_GetObjectItem(root, "param");
    if (param != NULL && cJSON_IsString(param)) {
        strncpy((char *)rule.param, cJSON_GetStringValue(param), sizeof(rule.param) - 1);
        rule.param[sizeof(rule.param) - 1] = '\0';
    }

    cJSON *action_param = cJSON_GetObjectItem(root, "action_param");
    if (action_param != NULL && cJSON_IsString(action_param)) {
        strncpy((char *)rule.action_param, cJSON_GetStringValue(action_param), sizeof(rule.action_param) - 1);
        rule.action_param[sizeof(rule.action_param) - 1] = '\0';
    }

    int idx = reaction_rules_add(&rule);
    cJSON_Delete(root);
    if (idx < 0) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "reaction add failed", out, out_sz);
    }
    cJSON *res = cJSON_CreateNumber((double)idx);
    char *printed = cJSON_PrintUnformatted(res);
    esp_err_t rc = jsonrpc_send_result(-1, printed, out, out_sz);
    cJSON_Delete(res);
    cJSON_free(printed);
    return rc;
}

static esp_err_t rpc_reaction_remove(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    cJSON *idx_item = cJSON_GetObjectItem(root, "idx");
    if (idx_item == NULL || !cJSON_IsNumber(idx_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing idx", out, out_sz);
    }
    int idx = (int)cJSON_GetNumberValue(idx_item);
    cJSON_Delete(root);
    esp_err_t rc = reaction_rules_remove((uint8_t)idx);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "remove failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"removed\"", out, out_sz);
}

static esp_err_t rpc_reaction_list(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[1024];
    esp_err_t rc = reaction_rules_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "list failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_export_start(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    cJSON *mode_item = cJSON_GetObjectItem(root, "mode");
    if (mode_item == NULL || !cJSON_IsString(mode_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing mode", out, out_sz);
    }
    const char *mode_str = cJSON_GetStringValue(mode_item);
    export_mode_t mode = EXPORT_MODE_OFF;
    if (strcmp(mode_str, "pcap") == 0) mode = EXPORT_MODE_PCAP;
    else if (strcmp(mode_str, "pcapng") == 0) mode = EXPORT_MODE_PCAP_NG;
    else if (strcmp(mode_str, "netxml") == 0) mode = EXPORT_MODE_NETXML;
    else if (strcmp(mode_str, "csv") == 0) mode = EXPORT_MODE_CSV;
    else if (strcmp(mode_str, "jsonl") == 0) mode = EXPORT_MODE_JSONL;
    else if (strcmp(mode_str, "zstd") == 0) mode = EXPORT_MODE_ZST;
    else {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "mode must be pcap|pcapng|netxml|csv|jsonl|zstd", out, out_sz);
    }
    cJSON *path_item = cJSON_GetObjectItem(root, "path");
    const char *path = "/sd/export.pcap";
    if (path_item != NULL && cJSON_IsString(path_item)) {
        path = cJSON_GetStringValue(path_item);
    }
    cJSON_Delete(root);
    esp_err_t rc = export_start(mode, path);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "export start failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"started\"", out, out_sz);
}

static esp_err_t rpc_export_stop(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = export_stop();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "export stop failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"stopped\"", out, out_sz);
}

/* ============================================================================
 *  OFFENSIVE RESEARCH RPC METHODS
 * ============================================================================ */
static esp_err_t rpc_offensive_set_mode(const char *method, const char *params_json,
                                         char *out, size_t outsz)
{
    (void)method;
    uint32_t mask = 0;
    if (params_json && strlen(params_json) > 0) {
        char *end = NULL;
        mask = (uint32_t)strtoul(params_json, &end, 0);
    }
    offensive_set_mode(mask);
    snprintf(out, outsz, "{"mode":"0x%08" PRIx32 ""}", offensive_get_mode());
    return ESP_OK;
}

static esp_err_t rpc_offensive_get_mode(const char *method, const char *params_json,
                                         char *out, size_t outsz)
{
    (void)method; (void)params_json;
    snprintf(out, outsz, "{"mode":"0x%08" PRIx32 ""}", offensive_get_mode());
    return ESP_OK;
}

static esp_err_t rpc_offensive_pmkid(const char *method, const char *params_json,
                                     char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_pmkid_t pmkid;
    if (offensive_get_pmkid(&pmkid) != ESP_OK || !pmkid.valid) {
        snprintf(out, outsz, "{"error":"no_pmkid"}");
        return ESP_ERR_NOT_FOUND;
    }
    snprintf(out, outsz,
        "{"ap_bssid":"" MACSTR "","pmkid":""
        , MAC2STR(pmkid.ap_bssid));
    for (int i = 0; i < 16 && i < (int)outsz - 8; i++) {
        int n = strlen(out);
        snprintf(out + n, outsz - n, "%02x", pmkid.pmkid[i]);
    }
    int n = strlen(out);
    snprintf(out + n, outsz - n, ""}");
    return ESP_OK;
}

static esp_err_t rpc_offensive_sae(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_sae_timing_t t;
    offensive_get_sae_timing(&t);
    snprintf(out, outsz,
        "{"delta_ms":%" PRIu32 ","ap_bssid":"" MACSTR ""}",
        t.delta_us, MAC2STR(t.ap_bssid));
    return ESP_OK;
}

static esp_err_t rpc_offensive_dragonfly(const char *method, const char *params_json,
                                         char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_dragonfly_t d;
    if (offensive_get_dragonfly(&d) != ESP_OK || !d.valid) {
        snprintf(out, outsz, "{"error":"no_dragonfly"}");
        return ESP_ERR_NOT_FOUND;
    }
    snprintf(out, outsz,
        "{"ap_bssid":"" MACSTR "","ssid":"%s"}",
        MAC2STR(d.ap_bssid), d.ssid);
    return ESP_OK;
}

static esp_err_t rpc_offensive_ft(const char *method, const char *params_json,
                                  char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_ft_t ft;
    if (offensive_get_ft(&ft) != ESP_OK || !ft.valid) {
        snprintf(out, outsz, "{"error":"no_ft"}");
        return ESP_ERR_NOT_FOUND;
    }
    snprintf(out, outsz,
        "{"ap_bssid":"" MACSTR "","sta_mac":"" MACSTR "","
        ""reassoc_ms":%" PRIu32 "}",
        MAC2STR(ft.ap_bssid), MAC2STR(ft.sta_mac), ft.reassoc_time_us);
    return ESP_OK;
}

static esp_err_t rpc_offensive_11k(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_11k_t k;
    offensive_get_11k(&k);
    snprintf(out, outsz,
        "{"target_bssid":"" MACSTR "","neighbor_bssid":"" MACSTR "","
        ""channel":%d}",
        MAC2STR(k.target_bssid), MAC2STR(k.neighbor_bssid), k.channel);
    return ESP_OK;
}

static esp_err_t rpc_offensive_11v(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_11v_t v;
    offensive_get_11v(&v);
    snprintf(out, outsz,
        "{"ap_bssid":"" MACSTR "","target_bssid":"" MACSTR "","
        ""disassoc_timer":%d}",
        MAC2STR(v.ap_bssid), MAC2STR(v.target_bssid), v.disassoc_timer);
    return ESP_OK;
}

static esp_err_t rpc_offensive_wps(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_wps_t w;
    if (offensive_get_wps(&w) != ESP_OK || !w.valid) {
        snprintf(out, outsz, "{"error":"no_wps"}");
        return ESP_ERR_NOT_FOUND;
    }
    snprintf(out, outsz,
        "{"ap_bssid":"" MACSTR "","m1_len":%d}",
        MAC2STR(w.ap_bssid), w.m1_len);
    return ESP_OK;
}

static esp_err_t rpc_offensive_eap(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_eap_t e;
    offensive_get_eap(&e);
    snprintf(out, outsz,
        "{"ap_bssid":"" MACSTR "","sta_mac":"" MACSTR "","
        ""bytes":%d}",
        MAC2STR(e.ap_bssid), MAC2STR(e.sta_mac), e.challenge_len);
    return ESP_OK;
}

static esp_err_t rpc_offensive_json(const char *method, const char *params_json,
                                    char *out, size_t outsz)
{
    (void)method; (void)params_json;
    offensive_json(out, outsz);
    return ESP_OK;
}

static esp_err_t rpc_offensive_status(const char *method, const char *params_json,
                                      char *out, size_t outsz)
{
    (void)method; (void)params_json;
    snprintf(out, outsz, "{"enabled":%s}", offensive_get_mode() ? "true" : "false");
    return ESP_OK;
}

static esp_err_t rpc_offensive_clear(const char *method, const char *params_json,
                                     char *out, size_t outsz)
{
    (void)method; (void)params_json;
    offensive_deinit();
    snprintf(out, outsz, "{"status":"cleared"}");
    return ESP_OK;
}

static esp_err_t rpc_export_stats(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = export_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "export stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/* ============================================================================
 *  OFFENSIVE RESEARCH RPC METHODS
 * ============================================================================ */
static esp_err_t rpc_offensive_set_mode(const char *method, const char *params_json,
                                         char *out, size_t outsz)
{
    (void)method;
    uint32_t mask = 0;
    if (params_json && strlen(params_json) > 0) {
        char *end = NULL;
        mask = (uint32_t)strtoul(params_json, &end, 0);
    }
    offensive_set_mode(mask);
    snprintf(out, outsz, "{\"mode\":\"0x%08" PRIx32 "\"}", offensive_get_mode());
    return ESP_OK;
}

static esp_err_t rpc_offensive_get_mode(const char *method, const char *params_json,
                                         char *out, size_t outsz)
{
    (void)method; (void)params_json;
    snprintf(out, outsz, "{\"mode\":\"0x%08" PRIx32 "\"}", offensive_get_mode());
    return ESP_OK;
}

static esp_err_t rpc_offensive_pmkid(const char *method, const char *params_json,
                                     char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_pmkid_t pmkid;
    if (offensive_get_pmkid(&pmkid) != ESP_OK || !pmkid.valid) {
        snprintf(out, outsz, "{\"error\":\"no_pmkid\"}");
        return ESP_ERR_NOT_FOUND;
    }
    snprintf(out, outsz, "{\"ap_bssid\":\"" MACSTR "\",\"pmkid\":\"", MAC2STR(pmkid.ap_bssid));
    for (int i = 0; i < 16 && i < (int)outsz - 8; i++) {
        int n = strlen(out);
        snprintf(out + n, outsz - n, "%02x", pmkid.pmkid[i]);
    }
    int n = strlen(out);
    snprintf(out + n, outsz - n, "\"}");
    return ESP_OK;
}

static esp_err_t rpc_offensive_sae(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_sae_timing_t t;
    offensive_get_sae_timing(&t);
    snprintf(out, outsz,
        "{\"delta_ms\":%" PRIu32 ",\"ap_bssid\":\"" MACSTR "\"}",
        t.delta_us, MAC2STR(t.ap_bssid));
    return ESP_OK;
}

static esp_err_t rpc_offensive_dragonfly(const char *method, const char *params_json,
                                         char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_dragonfly_t d;
    if (offensive_get_dragonfly(&d) != ESP_OK || !d.valid) {
        snprintf(out, outsz, "{\"error\":\"no_dragonfly\"}");
        return ESP_ERR_NOT_FOUND;
    }
    snprintf(out, outsz,
        "{\"ap_bssid\":\"" MACSTR "\",\"ssid\":\"%s\"}",
        MAC2STR(d.ap_bssid), d.ssid);
    return ESP_OK;
}

static esp_err_t rpc_offensive_ft(const char *method, const char *params_json,
                                  char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_ft_t ft;
    if (offensive_get_ft(&ft) != ESP_OK || !ft.valid) {
        snprintf(out, outsz, "{\"error\":\"no_ft\"}");
        return ESP_ERR_NOT_FOUND;
    }
    snprintf(out, outsz,
        "{\"ap_bssid\":\"" MACSTR "\",\"sta_mac\":\"" MACSTR "\","
        "\"reassoc_ms\":%" PRIu32 "}",
        MAC2STR(ft.ap_bssid), MAC2STR(ft.sta_mac), ft.reassoc_time_us);
    return ESP_OK;
}

static esp_err_t rpc_offensive_11k(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_11k_t k;
    offensive_get_11k(&k);
    snprintf(out, outsz,
        "{\"target_bssid\":\"" MACSTR "\",\"neighbor_bssid\":\"" MACSTR "\","
        "\"channel\":%d}",
        MAC2STR(k.target_bssid), MAC2STR(k.neighbor_bssid), k.channel);
    return ESP_OK;
}

static esp_err_t rpc_offensive_11v(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_11v_t v;
    offensive_get_11v(&v);
    snprintf(out, outsz,
        "{\"ap_bssid\":\"" MACSTR "\",\"target_bssid\":\"" MACSTR "\","
        "\"disassoc_timer\":%d}",
        MAC2STR(v.ap_bssid), MAC2STR(v.target_bssid), v.disassoc_timer);
    return ESP_OK;
}

static esp_err_t rpc_offensive_wps(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_wps_t w;
    if (offensive_get_wps(&w) != ESP_OK || !w.valid) {
        snprintf(out, outsz, "{\"error\":\"no_wps\"}");
        return ESP_ERR_NOT_FOUND;
    }
    snprintf(out, outsz,
        "{\"ap_bssid\":\"" MACSTR "\",\"m1_len\":%d}",
        MAC2STR(w.ap_bssid), w.m1_len);
    return ESP_OK;
}

static esp_err_t rpc_offensive_eap(const char *method, const char *params_json,
                                   char *out, size_t outsz)
{
    (void)method; (void)params_json;
    off_eap_t e;
    offensive_get_eap(&e);
    snprintf(out, outsz,
        "{\"ap_bssid\":\"" MACSTR "\",\"sta_mac\":\"" MACSTR "\","
        "\"bytes\":%d}",
        MAC2STR(e.ap_bssid), MAC2STR(e.sta_mac), e.challenge_len);
    return ESP_OK;
}

static esp_err_t rpc_offensive_json(const char *method, const char *params_json,
                                    char *out, size_t outsz)
{
    (void)method; (void)params_json;
    offensive_json(out, outsz);
    return ESP_OK;
}

static esp_err_t rpc_offensive_status(const char *method, const char *params_json,
                                      char *out, size_t outsz)
{
    (void)method; (void)params_json;
    snprintf(out, outsz, "{\"enabled\":%s}", offensive_get_mode() ? "true" : "false");
    return ESP_OK;
}

static esp_err_t rpc_offensive_clear(const char *method, const char *params_json,
                                     char *out, size_t outsz)
{
    (void)method; (void)params_json;
    offensive_deinit();
    snprintf(out, outsz, "{\"status\":\"cleared\"}");
    return ESP_OK;
}

/*============================================================================*/
static esp_err_t rpc_export_start(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *root = cJSON_Parse(params_json);
    if (root == NULL) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "invalid JSON", out, out_sz);
    }
    cJSON *mode_item = cJSON_GetObjectItem(root, "mode");
    if (mode_item == NULL || !cJSON_IsString(mode_item)) {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "missing mode", out, out_sz);
    }
    const char *mode_str = cJSON_GetStringValue(mode_item);
    export_mode_t mode = EXPORT_MODE_OFF;
    if (strcmp(mode_str, "pcap") == 0) mode = EXPORT_MODE_PCAP;
    else if (strcmp(mode_str, "pcapng") == 0) mode = EXPORT_MODE_PCAP_NG;
    else if (strcmp(mode_str, "netxml") == 0) mode = EXPORT_MODE_NETXML;
    else if (strcmp(mode_str, "csv") == 0) mode = EXPORT_MODE_CSV;
    else if (strcmp(mode_str, "jsonl") == 0) mode = EXPORT_MODE_JSONL;
    else if (strcmp(mode_str, "zstd") == 0) mode = EXPORT_MODE_ZST;
    else {
        cJSON_Delete(root);
        return jsonrpc_send_error(-1, JSONRPC_CODE_INVALID_PARAMS,
                                  "mode must be pcap|pcapng|netxml|csv|jsonl|zstd", out, out_sz);
    }
    cJSON *path_item = cJSON_GetObjectItem(root, "path");
    const char *path = "/sd/export.pcap";
    if (path_item != NULL && cJSON_IsString(path_item)) {
        path = cJSON_GetStringValue(path_item);
    }
    cJSON_Delete(root);
    esp_err_t rc = export_start(mode, path);
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "export start failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"started\"", out, out_sz);
}

static esp_err_t rpc_export_stop(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = export_stop();
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "export stop failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, "\"stopped\"", out, out_sz);
}

static esp_err_t rpc_export_stats(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = export_json(buf, sizeof(buf));
    if (rc != ESP_OK) {
        return jsonrpc_send_error(-1, JSONRPC_CODE_INTERNAL_ERROR,
                                  "export stats failed", out, out_sz);
    }
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_system_ping(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "\"pong\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_system_info(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "schema_version", SCHEMA_VERSION);
    cJSON_AddStringToObject(root, "firmware", "REAPER");
    cJSON_AddStringToObject(root, "chip", "ESP32-S3");
    const char *json = cJSON_PrintUnformatted(root);
    esp_err_t rc = jsonrpc_send_result(-1, json, out, out_sz);
    cJSON_free((void *)json);
    cJSON_Delete(root);
    return rc;
}

/*============================================================================*/
static esp_err_t rpc_system_caps(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char caps[256];
    esp_err_t rc = usb_cdc_caps_to_json(caps, sizeof(caps));
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, caps, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_system_health(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    health_metrics_t m;
    esp_err_t rc = health_telemetry_get(&m);
    if (rc != ESP_OK) return rc;
    char json[128];
    snprintf(json, sizeof(json),
        "{\"uptime_s\":%u,\"free_heap\":%u,\"free_psram\":%u,"
        "\"cpu_temp_c\":%.2f,\"min_free_heap\":%u}",
        m.uptime_s, m.free_heap, m.free_psram,
        (float)m.cpu_temp_c / 100.0f, m.min_free_heap);
    return jsonrpc_send_result(-1, json, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_system_crash(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[512];
    esp_err_t rc = watchdog_read_crash(buf, sizeof(buf));
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_wifi_scan(const char *method, const char *params_json,
                               char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "[]", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_wifi_start(const char *method, const char *params_json,
                                char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    wifi_sniffer_start();
    return jsonrpc_send_result(-1, "\"started\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_wifi_stop(const char *method, const char *params_json,
                               char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    wifi_sniffer_stop();
    return jsonrpc_send_result(-1, "\"stopped\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_wifi_channel(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *p = cJSON_Parse(params_json);
    if (!p) return jsonrpc_send_error(-1, -32600, "Invalid params", out, out_sz);
    cJSON *ch = cJSON_GetObjectItem(p, "channel");
    if (!cJSON_IsNumber(ch)) {
        cJSON_Delete(p);
        return jsonrpc_send_error(-1, -32600, "channel required", out, out_sz);
    }
    cJSON_Delete(p);
    return jsonrpc_send_result(-1, "\"ok\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_deauth_start(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "\"started\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_deauth_stop(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "\"stopped\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_deauth_status(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "{\"active\":false,\"sent\":0}", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_pcap_start(const char *method, const char *params_json,
                                char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = pcap_ring_start(0);
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "\"started\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_pcap_stop(const char *method, const char *params_json,
                               char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    pcap_ring_stop();
    return jsonrpc_send_result(-1, "\"stopped\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_pcap_save(const char *method, const char *params_json,
                               char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    const char *path = "/spiffs/capture.pcap";
    if (params_json) {
        cJSON *p = cJSON_Parse(params_json);
        if (p) {
            cJSON *jpath = cJSON_GetObjectItem(p, "path");
            if (cJSON_IsString(jpath)) path = cJSON_GetStringValue(jpath);
            cJSON_Delete(p);
        }
    }
    esp_err_t rc = pcap_ring_save(path);
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "{\"saved\":true}", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ble_scan(const char *method, const char *params_json,
                              char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "[]", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ble_stop(const char *method, const char *params_json,
                              char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "\"stopped\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ble_list(const char *method, const char *params_json,
                              char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "[]", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ble_mitm_add(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "{\"status\":\"target_added\"}", out, out_sz);
}

static esp_err_t rpc_ble_mitm_list(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "[]", out, out_sz);
}

static esp_err_t rpc_ble_gatt_enumerate(const char *method, const char *params_json,
                                        char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "{\"started\":true}", out, out_sz);
}

static esp_err_t rpc_ble_gatt_svcs(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "[]", out, out_sz);
}

static esp_err_t rpc_ble_gatt_chars(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "[]", out, out_sz);
}

static esp_err_t rpc_ble_findmy_list(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "[]", out, out_sz);
}

static esp_err_t rpc_ble_smarttag_list(const char *method, const char *params_json,
                                       char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "[]", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_thread_start(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = thread_br_start();
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "{\"status\":\"started\"}", out, out_sz);
}

static esp_err_t rpc_thread_stop(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = thread_br_stop();
    return jsonrpc_send_result(-1, "{\"status\":\"stopped\"}", out, out_sz);
}

static esp_err_t rpc_thread_status(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char json[64];
    snprintf(json, sizeof(json), "{\"active\":%s}", thread_br_is_active() ? "true" : "false");
    return jsonrpc_send_result(-1, json, out, out_sz);
}

static esp_err_t rpc_matter_start(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = matter_commissioner_start(NULL);
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "{\"status\":\"started\"}", out, out_sz);
}

static esp_err_t rpc_matter_stop(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = matter_commissioner_stop();
    return jsonrpc_send_result(-1, "{\"status\":\"stopped\"}", out, out_sz);
}

static esp_err_t rpc_matter_status(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char json[64];
    snprintf(json, sizeof(json), "{\"active\":%s}", matter_commissioner_is_active() ? "true" : "false");
    return jsonrpc_send_result(-1, json, out, out_sz);
}

static esp_err_t rpc_zigbee_start(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = zigbee_sniffer_start(11);
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "{\"status\":\"started\"}", out, out_sz);
}

static esp_err_t rpc_zigbee_stop(const char *method, const char *params_json,
                                 char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = zigbee_sniffer_stop();
    return jsonrpc_send_result(-1, "{\"status\":\"stopped\"}", out, out_sz);
}

static esp_err_t rpc_zigbee_status(const char *method, const char *params_json,
                                   char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char json[64];
    snprintf(json, sizeof(json), "{\"active\":%s}", zigbee_sniffer_is_active() ? "true" : "false");
    return jsonrpc_send_result(-1, json, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_health_ai_status(const char *method, const char *params_json,
                                      char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return health_ai_monitor_json(out, out_sz);
}

static esp_err_t rpc_health_ai_heal(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = health_ai_monitor_heal();
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "{\"status\":\"healed\"}", out, out_sz);
}

static esp_err_t rpc_wordlist_count(const char *method, const char *params_json,
                                    char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char json[64];
    snprintf(json, sizeof(json), "{\"count\":%d}", (int)wordlist_manager_count());
    return jsonrpc_send_result(-1, json, out, out_sz);
}

static esp_err_t rpc_wordlist_lookup(const char *method, const char *params_json,
                                     char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    return jsonrpc_send_result(-1, "{\"found\":false}", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_storage_wordlist_list(const char *method, const char *params_json,
                                           char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    char buf[256];
    esp_err_t rc = storage_spiffs_list_wordlists_json(buf, sizeof(buf));
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, buf, out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_storage_wordlist_load(const char *method, const char *params_json,
                                           char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *p = cJSON_Parse(params_json);
    if (!p) return jsonrpc_send_error(-1, -32600, "Invalid params", out, out_sz);
    cJSON *jname = cJSON_GetObjectItem(p, "name");
    if (!cJSON_IsString(jname)) {
        cJSON_Delete(p);
        return jsonrpc_send_error(-1, -32600, "name required", out, out_sz);
    }
    const char *name = cJSON_GetStringValue(jname);
    esp_err_t rc = storage_spiffs_load_wordlist_meta(name);
    cJSON_Delete(p);
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "{\"loaded\":true}", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_storage_nvs_reset(const char *method, const char *params_json,
                                       char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    esp_err_t rc = nvs_erase_all();
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "\"reset\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ota_start(const char *method, const char *params_json,
                               char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)user_ctx;
    cJSON *p = cJSON_Parse(params_json);
    if (!p) return jsonrpc_send_error(-1, -32600, "Invalid params", out, out_sz);
    cJSON *jurl = cJSON_GetObjectItem(p, "url");
    if (!cJSON_IsString(jurl)) {
        cJSON_Delete(p);
        return jsonrpc_send_error(-1, -32600, "url required", out, out_sz);
    }
    const char *url = cJSON_GetStringValue(jurl);
    cJSON_Delete(p);
    esp_err_t rc = ota_http_start(url);
    if (rc != ESP_OK) return rc;
    return jsonrpc_send_result(-1, "\"started\"", out, out_sz);
}

/*============================================================================*/
static esp_err_t rpc_ota_progress(const char *method, const char *params_json,
                                  char *out, size_t out_sz, void *user_ctx)
{
    (void)method; (void)params_json; (void)user_ctx;
    int progress = ota_http_progress();
    char json[64];
    snprintf(json, sizeof(json), "{\"progress\":%d}", progress);
    return jsonrpc_send_result(-1, json, out, out_sz);
}

/*============================================================================*/
static uint16_t build_system_methods(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (cap < 60) return 0;
    table[0].name = "system.ping";      table[0].fn = rpc_system_ping;      table[0].user_ctx = NULL;
    table[1].name = "system.info";      table[1].fn = rpc_system_info;      table[1].user_ctx = NULL;
    table[2].name = "system.caps";      table[2].fn = rpc_system_caps;      table[2].user_ctx = NULL;
    table[3].name = "system.health";    table[3].fn = rpc_system_health;    table[3].user_ctx = NULL;
    table[4].name = "system.crash";     table[4].fn = rpc_system_crash;     table[4].user_ctx = NULL;
    table[5].name = "gps.set_fix";      table[5].fn = rpc_gps_set_fix;      table[5].user_ctx = NULL;
    table[6].name = "gps.get_fix";      table[6].fn = rpc_gps_get_fix;      table[6].user_ctx = NULL;
    table[7].name = "gps.status";       table[7].fn = rpc_gps_status;       table[7].user_ctx = NULL;
    table[8].name = "coex.set_pref";    table[8].fn = rpc_coex_set_pref;    table[8].user_ctx = NULL;
    table[9].name = "coex.get_status";  table[9].fn = rpc_coex_get_status;  table[9].user_ctx = NULL;
    table[10].name = "coex.json";       table[10].fn = rpc_coex_json;       table[10].user_ctx = NULL;
    table[11].name = "ai.model.load";   table[11].fn = rpc_ai_load;         table[11].user_ctx = NULL;
    table[12].name = "ai.model.unload"; table[12].fn = rpc_ai_unload;       table[12].user_ctx = NULL;
    table[13].name = "ai.model.infer";  table[13].fn = rpc_ai_infer;        table[13].user_ctx = NULL;
    table[14].name = "ai.model.list";   table[14].fn = rpc_ai_list;         table[14].user_ctx = NULL;
    table[15].name = "ai.classify.test";table[15].fn = rpc_ai_classify_test;table[15].user_ctx = NULL;
    table[16].name = "ai.classify.stats";table[16].fn = rpc_ai_classify_stats;table[16].user_ctx = NULL;
    table[17].name = "ai.classify.set_model";table[17].fn = rpc_ai_classify_set_model;table[17].user_ctx = NULL;
    table[18].name = "ai.anomaly.set_model"; table[18].fn = rpc_ai_anomaly_set_model; table[18].user_ctx = NULL;
    table[19].name = "ai.anomaly.set_threshold"; table[19].fn = rpc_ai_anomaly_set_threshold; table[19].user_ctx = NULL;
    table[20].name = "ai.anomaly.stats"; table[20].fn = rpc_ai_anomaly_stats; table[20].user_ctx = NULL;
    table[21].name = "ai.fp.set_model"; table[21].fn = rpc_ai_fp_set_model;   table[21].user_ctx = NULL;
    table[22].name = "ai.fp.stats";     table[22].fn = rpc_ai_fp_stats;       table[22].user_ctx = NULL;
    table[23].name = "ai.fp.test";      table[23].fn = rpc_ai_fp_test;        table[23].user_ctx = NULL;
    table[24].name = "ai.channel.predict"; table[24].fn = rpc_ai_channel_predict; table[24].user_ctx = NULL;
    table[25].name = "ai.channel.stats"; table[25].fn = rpc_ai_channel_stats; table[25].user_ctx = NULL;
    table[26].name = "ai.channel.record"; table[26].fn = rpc_ai_channel_record; table[26].user_ctx = NULL;
    table[27].name = "ai.channel.set_model"; table[27].fn = rpc_ai_channel_set_model; table[27].user_ctx = NULL;
    table[28].name = "ai.hs.score";     table[28].fn = rpc_ai_hs_score;      table[28].user_ctx = NULL;
    table[29].name = "ai.hs.stats";     table[29].fn = rpc_ai_hs_stats;      table[29].user_ctx = NULL;
    table[30].name = "ai.hs.set_model"; table[30].fn = rpc_ai_hs_set_model;   table[30].user_ctx = NULL;
    table[31].name = "ai.hs.test";      table[31].fn = rpc_ai_hs_test;        table[31].user_ctx = NULL;
    table[32].name = "ai.rogue.scan";   table[32].fn = rpc_ai_rogue_scan;    table[32].user_ctx = NULL;
    table[33].name = "ai.rogue.alerts"; table[33].fn = rpc_ai_rogue_alerts;  table[33].user_ctx = NULL;
    table[34].name = "ai.deauth.predict"; table[34].fn = rpc_ai_deauth_predict; table[34].user_ctx = NULL;
    table[35].name = "ai.deauth.predict_all"; table[35].fn = rpc_ai_deauth_predict_all; table[35].user_ctx = NULL;
    table[36].name = "ai.deauth.stats"; table[36].fn = rpc_ai_deauth_stats; table[36].user_ctx = NULL;
    table[37].name = "ai.deauth.set_model"; table[37].fn = rpc_ai_deauth_set_model; table[37].user_ctx = NULL;
    table[38].name = "ai.ble.classify"; table[38].fn = rpc_ai_ble_classify; table[38].user_ctx = NULL;
    table[39].name = "ai.ble.stats";    table[39].fn = rpc_ai_ble_stats;    table[39].user_ctx = NULL;
    table[40].name = "ai.ble.set_model"; table[40].fn = rpc_ai_ble_set_model; table[40].user_ctx = NULL;
    table[41].name = "ai.train.start";  table[41].fn = rpc_ai_train_start;  table[41].user_ctx = NULL;
    table[42].name = "ai.train.stop";   table[42].fn = rpc_ai_train_stop;   table[42].user_ctx = NULL;
    table[43].name = "ai.train.stats";  table[43].fn = rpc_ai_train_stats;  table[43].user_ctx = NULL;
    table[44].name = "ai.train.status"; table[44].fn = rpc_ai_train_status; table[44].user_ctx = NULL;
    table[45].name = "wardrive.start";  table[45].fn = rpc_wardrive_start;  table[45].user_ctx = NULL;
    table[46].name = "wardrive.stop";   table[46].fn = rpc_wardrive_stop;   table[46].user_ctx = NULL;
    table[47].name = "wardrive.stats";  table[47].fn = rpc_wardrive_stats;  table[47].user_ctx = NULL;
    table[48].name = "wardrive.status"; table[48].fn = rpc_wardrive_status; table[48].user_ctx = NULL;
    table[49].name = "attack.plan";     table[49].fn = rpc_attack_plan;     table[49].user_ctx = NULL;
    table[50].name = "attack.best";     table[50].fn = rpc_attack_best;     table[50].user_ctx = NULL;
    table[51].name = "attack.stats";    table[51].fn = rpc_attack_stats;    table[51].user_ctx = NULL;
    table[52].name = "stealth.set_mode"; table[52].fn = rpc_stealth_set_mode; table[52].user_ctx = NULL;
    table[53].name = "stealth.rotate_mac"; table[53].fn = rpc_stealth_rotate; table[53].user_ctx = NULL;
    table[54].name = "stealth.status";  table[54].fn = rpc_stealth_status;  table[54].user_ctx = NULL;
    table[55].name = "scheduler.add";   table[55].fn = rpc_scheduler_add;   table[55].user_ctx = NULL;
    table[56].name = "scheduler.remove"; table[56].fn = rpc_scheduler_remove; table[56].user_ctx = NULL;
    table[57].name = "scheduler.update"; table[57].fn = rpc_scheduler_update; table[57].user_ctx = NULL;
    table[58].name = "scheduler.list";  table[58].fn = rpc_scheduler_list;  table[58].user_ctx = NULL;
    table[59].name = "scheduler.save";  table[59].fn = rpc_scheduler_save;  table[59].user_ctx = NULL;
    table[60].name = "reaction.add";    table[60].fn = rpc_reaction_add;    table[60].user_ctx = NULL;
    table[61].name = "reaction.remove"; table[61].fn = rpc_reaction_remove; table[61].user_ctx = NULL;
    table[62].name = "reaction.list";   table[62].fn = rpc_reaction_list;   table[62].user_ctx = NULL;
    table[63].name = "export.start";    table[63].fn = rpc_export_start;    table[63].user_ctx = NULL;
    table[64].name = "export.stop";     table[64].fn = rpc_export_stop;     table[64].user_ctx = NULL;
    table[65].name = "export.stats";    table[65].fn = rpc_export_stats;    table[65].user_ctx = NULL;
    table[66].name = "offensive.set_mode"; table[66].fn = rpc_offensive_set_mode; table[66].user_ctx = NULL;
    table[67].name = "offensive.get_mode"; table[67].fn = rpc_offensive_get_mode; table[67].user_ctx = NULL;
    table[68].name = "offensive.pmkid";    table[68].fn = rpc_offensive_pmkid;    table[68].user_ctx = NULL;
    table[69].name = "offensive.sae";      table[69].fn = rpc_offensive_sae;      table[69].user_ctx = NULL;
    table[70].name = "offensive.dragonfly"; table[70].fn = rpc_offensive_dragonfly; table[70].user_ctx = NULL;
    table[71].name = "offensive.ft";        table[71].fn = rpc_offensive_ft;        table[71].user_ctx = NULL;
    table[72].name = "offensive.11k";       table[72].fn = rpc_offensive_11k;       table[72].user_ctx = NULL;
    table[73].name = "offensive.11v";       table[73].fn = rpc_offensive_11v;       table[73].user_ctx = NULL;
    table[74].name = "offensive.wps";       table[74].fn = rpc_offensive_wps;       table[74].user_ctx = NULL;
    table[75].name = "offensive.eap";       table[75].fn = rpc_offensive_eap;       table[75].user_ctx = NULL;
    table[76].name = "offensive.json";      table[76].fn = rpc_offensive_json;      table[76].user_ctx = NULL;
    table[77].name = "offensive.status";    table[77].fn = rpc_offensive_status;    table[77].user_ctx = NULL;
    table[78].name = "offensive.clear";     table[78].fn = rpc_offensive_clear;     table[78].user_ctx = NULL;
    table[79].name = "health.ai.status";    table[79].fn = rpc_health_ai_status;    table[79].user_ctx = NULL;
    table[80].name = "health.ai.heal";      table[80].fn = rpc_health_ai_heal;      table[80].user_ctx = NULL;
    table[81].name = "wordlist.count";      table[81].fn = rpc_wordlist_count;      table[81].user_ctx = NULL;
    table[82].name = "wordlist.lookup";     table[82].fn = rpc_wordlist_lookup;     table[82].user_ctx = NULL;
    return 83;
}

static uint16_t build_wifi_methods(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (cap < 4) return 0;
    table[0].name = "wifi.scan";      table[0].fn = rpc_wifi_scan;      table[0].user_ctx = NULL;
    table[1].name = "wifi.start";     table[1].fn = rpc_wifi_start;     table[1].user_ctx = NULL;
    table[2].name = "wifi.stop";      table[2].fn = rpc_wifi_stop;      table[2].user_ctx = NULL;
    table[3].name = "wifi.channel";   table[3].fn = rpc_wifi_channel;   table[3].user_ctx = NULL;
    return 4;
}

static uint16_t build_deauth_methods(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (cap < 3) return 0;
    table[0].name = "deauth.start";   table[0].fn = rpc_deauth_start;   table[0].user_ctx = NULL;
    table[1].name = "deauth.stop";    table[1].fn = rpc_deauth_stop;    table[1].user_ctx = NULL;
    table[2].name = "deauth.status";  table[2].fn = rpc_deauth_status;  table[2].user_ctx = NULL;
    return 3;
}

static uint16_t build_pcap_methods(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (cap < 3) return 0;
    table[0].name = "pcap.start";     table[0].fn = rpc_pcap_start;     table[0].user_ctx = NULL;
    table[1].name = "pcap.stop";      table[1].fn = rpc_pcap_stop;      table[1].user_ctx = NULL;
    table[2].name = "pcap.save";      table[2].fn = rpc_pcap_save;      table[2].user_ctx = NULL;
    return 3;
}

static uint16_t build_ble_methods(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (cap < 10) return 0;
    table[0].name = "ble.scan";            table[0].fn = rpc_ble_scan;            table[0].user_ctx = NULL;
    table[1].name = "ble.stop";            table[1].fn = rpc_ble_stop;            table[1].user_ctx = NULL;
    table[2].name = "ble.list";            table[2].fn = rpc_ble_list;            table[2].user_ctx = NULL;
    table[3].name = "ble.mitm.add";        table[3].fn = rpc_ble_mitm_add;        table[3].user_ctx = NULL;
    table[4].name = "ble.mitm.list";       table[4].fn = rpc_ble_mitm_list;       table[4].user_ctx = NULL;
    table[5].name = "ble.gatt.enumerate";  table[5].fn = rpc_ble_gatt_enumerate;  table[5].user_ctx = NULL;
    table[6].name = "ble.gatt.svcs";       table[6].fn = rpc_ble_gatt_svcs;       table[6].user_ctx = NULL;
    table[7].name = "ble.gatt.chars";      table[7].fn = rpc_ble_gatt_chars;      table[7].user_ctx = NULL;
    table[8].name = "ble.findmy.list";     table[8].fn = rpc_ble_findmy_list;     table[8].user_ctx = NULL;
    table[9].name = "ble.smarttag.list";   table[9].fn = rpc_ble_smarttag_list;   table[9].user_ctx = NULL;
    return 10;
}

static uint16_t build_80215_methods(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (cap < 9) return 0;
    table[0].name = "thread.start";     table[0].fn = rpc_thread_start;     table[0].user_ctx = NULL;
    table[1].name = "thread.stop";      table[1].fn = rpc_thread_stop;      table[1].user_ctx = NULL;
    table[2].name = "thread.status";    table[2].fn = rpc_thread_status;    table[2].user_ctx = NULL;
    table[3].name = "matter.start";     table[3].fn = rpc_matter_start;     table[3].user_ctx = NULL;
    table[4].name = "matter.stop";      table[4].fn = rpc_matter_stop;      table[4].user_ctx = NULL;
    table[5].name = "matter.status";    table[5].fn = rpc_matter_status;    table[5].user_ctx = NULL;
    table[6].name = "zigbee.start";     table[6].fn = rpc_zigbee_start;     table[6].user_ctx = NULL;
    table[7].name = "zigbee.stop";      table[7].fn = rpc_zigbee_stop;      table[7].user_ctx = NULL;
    table[8].name = "zigbee.status";    table[8].fn = rpc_zigbee_status;    table[8].user_ctx = NULL;
    return 9;
}

static uint16_t build_storage_methods(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (cap < 3) return 0;
    table[0].name = "storage.wordlist.list";      table[0].fn = rpc_storage_wordlist_list;      table[0].user_ctx = NULL;
    table[1].name = "storage.wordlist.load";      table[1].fn = rpc_storage_wordlist_load;      table[1].user_ctx = NULL;
    table[2].name = "storage.nvs.factory_reset";  table[2].fn = rpc_storage_nvs_reset;          table[2].user_ctx = NULL;
    return 3;
}

static uint16_t build_ota_methods(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (cap < 2) return 0;
    table[0].name = "ota.start";      table[0].fn = rpc_ota_start;      table[0].user_ctx = NULL;
    table[1].name = "ota.progress";   table[1].fn = rpc_ota_progress;   table[1].user_ctx = NULL;
    return 2;
}

/*============================================================================*/
const char *jsonrpc_schema_version(void)
{
    return SCHEMA_VERSION;
}

/*============================================================================*/
uint16_t jsonrpc_schema_v1_build(jsonrpc_method_entry_t *table, uint16_t cap)
{
    if (table == NULL || cap == 0) {
        return 0;
    }

    uint16_t offset = 0;
    offset += build_system_methods(table + offset, cap - offset);
    offset += build_wifi_methods(table + offset, cap - offset);
    offset += build_deauth_methods(table + offset, cap - offset);
    offset += build_pcap_methods(table + offset, cap - offset);
    offset += build_ble_methods(table + offset, cap - offset);
    offset += build_80215_methods(table + offset, cap - offset);
    offset += build_storage_methods(table + offset, cap - offset);
    offset += build_ota_methods(table + offset, cap - offset);
    offset += build_platform_methods(table + offset, cap - offset);

    return offset;
}

/*============================================================================*/
esp_err_t jsonrpc_schema_event_post(jsonrpc_event_type_t type, const char *event_json)
{
    if (event_json == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    return jsonrpc_event_post(type, event_json);
}
