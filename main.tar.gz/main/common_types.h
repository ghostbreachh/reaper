#ifndef COMMON_TYPES_H
#define COMMON_TYPES_H

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <inttypes.h>
#include <sys/time.h>
#include <sys/stat.h>

#include "esp_err.h"
#include "esp_log.h"

// ============================================================================
//  SECTION 1: LED MODULE TYPES
// ============================================================================

typedef enum {
    LED_STATE_OFF = 0,
    LED_STATE_IDLE,
    LED_STATE_SCANNING,
    LED_STATE_CONNECTED,
    LED_STATE_ERROR,
    LED_STATE_CUSTOM
} led_state_t;

typedef struct {
    uint8_t r;
    uint8_t g;
    uint8_t b;
} Color;

// ============================================================================
//  SECTION 2: WI-FI PROMISCUOUS SNIFFER TYPES
// ============================================================================

#define MAX_DISCOVERED_APS     50
#define MAX_DISCOVERED_CLIENTS 100

typedef struct {
    uint8_t bssid[6];
    uint8_t channel;
    uint8_t phy_mode; /* 0=unknown, 1=b, 2=a/g, 3=n, 4=ac, 5=ax */
} neighbor_entry_t;

typedef struct {
    uint8_t bssid[6];
    char ssid[33];
    int8_t rssi;
    uint8_t channel;
    uint32_t pkt_count;
    bool pmf_capable;
    bool pmf_required;
    uint16_t rsn_version;
    bool wpa3_sae;
    uint8_t akm_count;
    /* 802.11k/v/r neighbor report support */
    bool has_rrm;
    bool has_btm;
    uint8_t neighbor_count;
    neighbor_entry_t neighbors[8];
    /* Multi-BSSID support */
    bool is_multi_bssid;
    bool is_transmitted_bssid;
    uint8_t max_bssid_indicator;
    uint8_t bssid_index;
    /* HE capabilities */
    bool he_capable;
    uint8_t he_mcs_nss; /* bit 0-3 = NSS, bit 4-7 = MCS */
    uint8_t he_ppdu_type; /* 0=unknown, 1=he-mu, 2=he-su */
    /* Regulatory domain */
    bool regdom_present;
    char country_code[3]; /* "US", "EU", "JP", etc. */
    uint8_t reg_class;
    uint8_t max_tx_power;
    /* AI device fingerprinting */
    bool fp_done;
    uint8_t fp_oui[3];
    uint8_t fp_rates[8];
    uint8_t fp_rate_count;
    uint8_t fp_ext_cap[8];
    uint8_t fp_ext_cap_len;
    uint8_t fp_class; /* 0=unknown, 1=phone, 2=laptop, 3=iot, 4=ap, 5=router */
    char fp_label[32];
} ap_info_t;

typedef struct {
    uint8_t mac[6];
    uint8_t ap_bssid[6];
    int8_t rssi;
    uint8_t channel;
    uint32_t pkt_count;
} client_info_t;

typedef struct {
    uint32_t total_mgmt;
    uint32_t total_data;
    uint32_t beacon;
    uint32_t probe_req;
    uint32_t probe_resp;
    uint32_t deauth;
    uint32_t disassoc;
} wifi_stats_t;

typedef struct {
    uint8_t *payload;
    size_t len;
    int8_t rssi;
    uint8_t channel;
    struct timeval tv;
} wifi_pkt_msg_t;

typedef struct __attribute__((packed)) {
    uint16_t frame_ctrl;
    uint16_t duration;
    uint8_t addr1[6];
    uint8_t addr2[6];
    uint8_t addr3[6];
    uint16_t seq_ctrl;
} wifi_ieee80211_mac_hdr_t;

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint16_t version_major;
    uint16_t version_minor;
    int32_t  thiszone;
    uint32_t sigfigs;
    uint32_t snaplen;
    uint32_t network;
} pcap_file_header_t;

typedef struct __attribute__((packed)) {
    uint32_t ts_sec;
    uint32_t ts_usec;
    uint32_t incl_len;
    uint32_t orig_len;
} pcaprec_hdr_t;

// ============================================================================
//  SECTION 3: BLE SCANNER TYPES
// ============================================================================

#define MAX_DISCOVERED_BLE 50

typedef struct {
    uint8_t mac[6];
    uint8_t addr_type;
    char name[33];
    int8_t rssi;
    uint16_t mfg_id;
    uint32_t pkt_count;
    uint8_t tracker_score;
    /* BT 5.0 extended advertising */
    bool ext_adv_seen;
    bool has_aux_ptr;
    bool has_adi;
    bool has_scan_rsp;
    uint8_t adv_mode; /* 0=legacy, 1=non-conn, 2=scan */
    uint8_t tx_power; /* dBm from AD ext header, if present */
    /* BT 5.0 periodic advertising / sync transfer */
    bool periodic_adv_seen;
    bool has_sync_info;
    bool sync_transfer_seen;
    uint16_t periodic_adv_interval; /* units of 1.25 ms, 0 = unknown */
    uint8_t sync_handle; /* advertising SID from ADI or sync info */
    /* BT 5.0 coded PHY long-range */
    bool phy_coded;       /* true if received on coded PHY */
    bool phy_coded_s8;    /* true if specifically S=8 coding */
    bool phy_1m;          /* received on 1M PHY */
    bool phy_2m;          /* received on 2M PHY */
    bool phy_coded_supported; /* advertiser claims coded PHY support */
    /* BLE privacy / RPA */
    bool rpa_seen;            /* true if address looks like resolvable private */
    bool irk_hash_seen;       /* true if we saw a hash we can track */
    uint8_t irk_hash[3];      /* lower 3 bytes of RPA hash */
    /* BT 5.2 ISO / isochronous channels */
    bool iso_seen;            /* true if ISO/BIG-related data seen */
    bool has_big_info;        /* true if Broadcast ISO event detected */
    uint8_t iso_channels;     /* number of ISO channels advertised */
    uint8_t bis_handles[4];   /* BIS handle array, max 4 */
    uint32_t iso_interval_us; /* ISO interval in microseconds, 0=unknown */
} ble_info_t;

// ============================================================================
//  SECTION 4: BOOT PORT DETECTION
// ============================================================================

// Transport modes chosen at boot based on detected USB port.
typedef enum {
    PORT_TRANSPORT_UART0 = 0,   // USB-Serial-JTAG / COM port console
    PORT_TRANSPORT_CDC,         // USB-OTG CDC-ACM active
    PORT_TRANSPORT_UNKNOWN,     // No recognised transport found
    PORT_TRANSPORT_BOTH         // Rare: both PHYs reported (UART0 preferred)
} port_transport_t;

// Detailed detection result for diagnostics and phone-app handshake.
typedef struct {
    port_transport_t active;
    bool usb_serial_jtag_present;  // USB-Serial-JTAG enum found
    bool cdc_acm_present;          // TinyUSB CDC ACM interface found
    bool both_active;              // both USB funcs simultaneously detected
    char jtag_serial[32];          // iSerial if available, else empty
    char cdc_iface[16];            // e.g. "ttyACM0" hint for debug
    uint8_t reason;                // why a transport was chosen
} port_detect_result_t;

#define PORT_REASON_JTAG_ONLY   0x01
#define PORT_REASON_CDC_ONLY    0x02
#define PORT_REASON_BOTH        0x03
#define PORT_REASON_FALLBACK    0x04

// ============================================================================
//  SECTION 5: DEAUTH TYPES
// ============================================================================

#define MAX_TARGET_APS    10
#define MAX_TARGET_CLIENTS 20

typedef enum {
    DEAUTH_TYPE_SINGLE,
    DEAUTH_TYPE_ALL,
    DEAUTH_TYPE_BROADCAST
} deauth_type_t;

typedef enum {
    DEAUTH_FALLBACK_NONE = 0,
    DEAUTH_FALLBACK_DISASSOC = 1,
    DEAUTH_FALLBACK_AUTH_FLOOD = 2
} deauth_fallback_t;

typedef enum {
    DEAUTH_MODE_FALLBACK_CHAIN = 0,
    DEAUTH_MODE_DEAUTH_ONLY    = 1,
    DEAUTH_MODE_DISASSOC_ONLY  = 2,
    DEAUTH_MODE_AUTH_FLOOD_ONLY = 3
} deauth_mode_t;

typedef struct {
    uint8_t bssid[6];
    uint8_t client_mac[6];
    deauth_type_t type;
    uint32_t count;
    uint32_t delay_ms;
    bool active;
    bool wpa3_sae;
    bool pmf_required;
    deauth_mode_t mode;
    deauth_fallback_t fallback_level;
    uint32_t disassoc_count;
    uint32_t auth_count;
} deauth_target_t;

// ============================================================================
//  SECTION 6: WPA HANDSHAKE TYPES
// ============================================================================

#define EAPOL_BUF_SIZE 256

typedef struct {
    bool valid;
    bool has_pmkid;
    uint8_t ap_mac[6];
    uint8_t sta_mac[6];
    char ssid[33];
    uint8_t anonce[32];
    uint8_t snonce[32];
    uint8_t mic[16];
    uint8_t pmkid[16];
    uint8_t eapol[EAPOL_BUF_SIZE];
    uint16_t eapol_len;
    int64_t capture_time_us;
} handshake_t;

// ============================================================================
//  SECTION 7: ARP POISON TYPES
// ============================================================================

#define MAX_ARP_TABLE 32

typedef struct {
    uint8_t mac[6];
    uint8_t ip[4];
    uint8_t ap_bssid[6];
    bool    is_gateway;
    uint32_t pkt_count;
} arp_host_t;

// ============================================================================
//  SECTION 8: CREDENTIAL / PLAINTEXT SNIFFER
// ============================================================================

#define MAX_CREDS 32

typedef struct {
    char host[64];
    char user[48];
    char pass[64];
    char cookie[96];
    char path[64];
    uint8_t src_ip[4];
    uint8_t dst_ip[4];
    int64_t time_us;
} cred_hit_t;

/* ============================================================================
 *  SECTION 9: GPS / TIMESTAMP CORRELATION
 * ============================================================================
 */

typedef struct {
    bool valid;
    double latitude;
    double longitude;
    double altitude;
    double speed_knots;
    uint32_t timestamp; /* Unix epoch from GPS */
    uint8_t sat_count;
    uint8_t fix_quality; /* 0=none, 1=GPS, 2=DGPS */
} gps_fix_t;

#endif // COMMON_TYPES_H
